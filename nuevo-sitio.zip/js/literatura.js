$(document).ready(function(){
	$("#acordeon").accordion();
});

